import React, { useEffect, useRef, useState } from "react";
import Todo from "./components/Todo";
import Forms from "./components/Form";
import { nanoid } from "nanoid";
import FilterButton from "./components/FilterButton";

function About(props) {
    return (
    
        <div>
            <h1>What about us?</h1>
        </div>);
};

export default About;